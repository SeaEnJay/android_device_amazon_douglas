for var in userdebug; do
 add_lunch_combo lineage_aquaris_m8-$var
done